package by.bsuir.lab2.service.validation;

import by.bsuir.lab2.entity.criteria.Criteria;

public class Validator {

	public static boolean criteriaValidator(Criteria criteria) {
		// you may add your own code here

		return true;
	}

}

// you may add your own new classes